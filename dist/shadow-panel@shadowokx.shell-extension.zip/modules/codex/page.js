import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import St from 'gi://St';

import {formatCountdown, formatResetDate} from '../../lib/format.js';
import {codexUsageStatus} from '../../lib/summary.js';
import {launchUri} from '../../services/launcher.js';
import {
    ProgressMeter,
    iconButton,
    moduleIconButton,
    moduleIcon,
    pageTitle,
    resolveAccent,
    scrollContainer,
    sectionTitle,
    stateMessage,
    textButton,
} from '../../ui/components.js';
import {BasePage} from '../basePage.js';
import {exportCodexSummaryImage} from './shareImage.js';

export class CodexPage extends BasePage {
    constructor(context) {
        super(context, 'codex');
        this._provider = context.codexProvider;
        this._sharing = false;
        this._destroyed = false;
        this._popupOpen = false;
        this._lastWeeklyPercent = null;
        this.track(this._provider.subscribe(() => this._render()));
    }

    onPopupOpened() {
        this._popupOpen = true;
        this._lastWeeklyPercent = null;
        this._render();
        this.context.scheduler.every('codex-countdown', 60, () => this._render());
        if (this.context.settings.get_boolean('refresh-on-open') && this._provider.isStale())
            this._provider.refresh(false);
    }

    onPopupClosed() {
        this._popupOpen = false;
        this.context.scheduler.cancel('codex-countdown');
    }

    _render() {
        if (this._destroyed || this._pageDestroyed || !this.actor)
            return;
        const state = this._provider.getState();
        this.replaceContent(page => {
            page.add_child(pageTitle(
                'Codex Usage',
                this._actions(state),
                moduleIcon(this.context.extension, 'codex', 19, 'shadow-page-brand-icon')
            ));

            if (state.status === 'loading' && !state.lastSuccessfulRefresh) {
                page.add_child(stateMessage(
                    'content-loading-symbolic',
                    'Loading Codex usage',
                    'Reading limits from the local Codex app-server…'
                ));
                return;
            }
            if (state.status === 'error' && !state.lastSuccessfulRefresh) {
                page.add_child(stateMessage(
                    'dialog-warning-symbolic',
                    'Codex usage unavailable',
                    state.error ?? 'No usage data has been reported yet.',
                    textButton('Retry', () => this._provider.refresh(true))
                ));
                return;
            }

            const content = new St.BoxLayout({
                vertical: true,
                style_class: 'shadow-codex-content',
                x_expand: true,
            });
            let sectionCount = 0;
            if (this.context.settings.get_boolean('show-codex-weekly')) {
                content.add_child(this._weeklyHero(state.weekly));
                sectionCount++;
            }
            if (this.context.settings.get_boolean('show-codex-five-hour')) {
                content.add_child(this._fiveHourSection(state.fiveHour));
                sectionCount++;
            }
            if (sectionCount === 0) {
                content.add_child(new St.Label({
                    text: 'Enable a usage window in Codex settings.',
                    style_class: 'shadow-inline-empty shadow-muted',
                }));
            }

            content.add_child(this._tokenActivity(state.tokenUsage));

            const facts = this._facts(state);
            if (facts)
                content.add_child(facts);
            page.add_child(scrollContainer(content, 'shadow-codex-scroll'));
        });
    }

    _actions(state) {
        const actions = new St.BoxLayout({style_class: 'shadow-title-actions'});
        actions.add_child(moduleIconButton(
            this.context.extension,
            'codex',
            'Open Codex application',
            () => this._openCodex(),
            'shadow-icon-button shadow-action-icon-button'
        ));
        actions.add_child(iconButton(
            'view-refresh-symbolic',
            'Refresh Codex usage',
            () => this._provider.refresh(true),
            'shadow-icon-button shadow-action-icon-button'
        ));
        const share = iconButton(
            this._sharing ? 'process-working-symbolic' : 'document-send-symbolic',
            this._sharing ? 'Creating usage image' : 'Create usage image',
            () => this._share(state),
            'shadow-icon-button shadow-action-icon-button'
        );
        share.reactive = !this._sharing && Boolean(state.weekly || state.fiveHour);
        share.can_focus = share.reactive;
        if (!share.reactive)
            share.opacity = 120;
        actions.add_child(share);
        return actions;
    }

    _weeklyHero(window) {
        const card = new St.BoxLayout({
            vertical: true,
            style_class: 'shadow-card shadow-weekly-hero',
            x_expand: true,
        });
        const heading = new St.BoxLayout({style_class: 'shadow-usage-heading', x_expand: true});
        heading.add_child(sectionTitle('Weekly capacity'));
        if (window) {
            const status = codexUsageStatus(window.remainingPercent);
            heading.add_child(new St.Label({
                text: status.label,
                style_class: 'shadow-usage-state',
            }));
        }
        card.add_child(heading);
        if (!window) {
            card.add_child(new St.Label({
                text: 'Unavailable',
                style_class: 'shadow-weekly-unavailable',
                x_align: Clutter.ActorAlign.START,
            }));
            card.add_child(new St.Label({
                text: 'Not reported by this Codex session.',
                style_class: 'shadow-muted',
                x_align: Clutter.ActorAlign.START,
            }));
            return card;
        }

        const value = new St.BoxLayout({style_class: 'shadow-weekly-value-row'});
        value.add_child(new St.Label({
            text: `${window.remainingPercent}%`,
            style_class: 'shadow-weekly-value',
            style: `color: ${resolveAccent(this.context.settings)};`,
        }));
        value.add_child(new St.Label({
            text: 'remaining',
            style_class: 'shadow-weekly-unit',
            y_align: Clutter.ActorAlign.END,
        }));
        card.add_child(value);

        const width = this.context.settings.get_string('density') === 'compact' ? 286 : 320;
        const animate = this._popupOpen && this._lastWeeklyPercent !== null &&
            this._lastWeeklyPercent !== window.remainingPercent &&
            this.context.settings.get_boolean('animations');
        this._lastWeeklyPercent = window.remainingPercent;
        card.add_child(new ProgressMeter(
            window.remainingPercent,
            resolveAccent(this.context.settings),
            width,
            'remaining',
            animate
        ).actor);

        const legend = new St.BoxLayout({style_class: 'shadow-progress-legend', x_expand: true});
        legend.add_child(new St.Label({
            text: `${100 - window.remainingPercent}% used`,
            style_class: 'shadow-muted',
            x_expand: true,
        }));
        legend.add_child(new St.Label({
            text: `${window.remainingPercent}% available`,
            style_class: 'shadow-progress-available',
        }));
        card.add_child(legend);

        if (this.context.settings.get_boolean('show-codex-reset-time')) {
            const reset = new St.BoxLayout({style_class: 'shadow-weekly-reset', x_expand: true});
            reset.add_child(new St.Label({
                text: formatCountdown(window.resetsAt),
                style_class: 'shadow-reset-countdown',
                x_expand: true,
            }));
            reset.add_child(new St.Label({
                text: formatResetDate(window.resetsAt),
                style_class: 'shadow-muted',
            }));
            card.add_child(reset);
        }
        return card;
    }

    _fiveHourSection(window) {
        const section = new St.BoxLayout({
            style_class: 'shadow-secondary-surface shadow-five-hour-section',
            x_expand: true,
        });
        const copy = new St.BoxLayout({vertical: true, x_expand: true});
        copy.add_child(new St.Label({
            text: '5-Hour Window',
            style_class: 'shadow-card-title',
            x_align: Clutter.ActorAlign.START,
        }));
        if (!window) {
            copy.add_child(new St.Label({
                text: 'Not reported by this Codex session.',
                style_class: 'shadow-muted',
                x_align: Clutter.ActorAlign.START,
            }));
            section.add_child(copy);
            section.add_child(new St.Label({
                text: 'Unavailable',
                style_class: 'shadow-five-hour-unavailable',
                y_align: Clutter.ActorAlign.CENTER,
            }));
            return section;
        }

        if (this.context.settings.get_boolean('show-codex-reset-time')) {
            copy.add_child(new St.Label({
                text: formatCountdown(window.resetsAt),
                style_class: 'shadow-muted',
                x_align: Clutter.ActorAlign.START,
            }));
        }
        section.add_child(copy);
        section.add_child(new St.Label({
            text: `${window.remainingPercent}% remaining`,
            style_class: 'shadow-five-hour-value',
            style: `color: ${resolveAccent(this.context.settings)};`,
            y_align: Clutter.ActorAlign.CENTER,
        }));
        return section;
    }

    _tokenActivity(usage) {
        const card = new St.BoxLayout({
            vertical: true,
            style_class: 'shadow-secondary-surface shadow-token-activity',
            x_expand: true,
        });
        card.add_child(sectionTitle('Token activity'));
        if (!usage) {
            card.add_child(new St.Label({
                text: 'Token activity is not reported by this Codex session.',
                style_class: 'shadow-token-note shadow-muted',
                x_align: Clutter.ActorAlign.START,
            }));
            return card;
        }

        const primary = new St.BoxLayout({style_class: 'shadow-token-primary-row', x_expand: true});
        if (Number.isSafeInteger(usage.lifetimeTokens))
            primary.add_child(this._tokenMetric('Lifetime tokens', this._formatTokens(usage.lifetimeTokens), true));
        if (Number.isSafeInteger(usage.todayTokens))
            primary.add_child(this._tokenMetric('Today', this._formatTokens(usage.todayTokens)));
        if (primary.get_children().length > 0)
            card.add_child(primary);

        const secondary = new St.BoxLayout({style_class: 'shadow-token-row', x_expand: true});
        const peakDate = this._formatUsageDate(usage.peakDate);
        const peakTokens = this._formatTokens(usage.peakDailyTokens);
        if (peakDate)
            secondary.add_child(this._tokenMetric('Peak day', peakDate));
        if (peakTokens)
            secondary.add_child(this._tokenMetric('Peak-day tokens', peakTokens));
        if (secondary.get_children().length > 0)
            card.add_child(secondary);
        return card;
    }

    _tokenMetric(label, value, primary = false) {
        const metric = new St.BoxLayout({
            vertical: true,
            style_class: primary ? 'shadow-token-metric shadow-token-primary' : 'shadow-token-metric',
            x_expand: true,
        });
        metric.add_child(new St.Label({text: label, style_class: 'shadow-token-label'}));
        metric.add_child(new St.Label({
            text: value,
            style_class: primary ? 'shadow-token-primary-value' : 'shadow-token-value',
        }));
        return metric;
    }

    _formatTokens(value) {
        return Number.isSafeInteger(value) ? new Intl.NumberFormat('en-US').format(value) : null;
    }

    _formatUsageDate(value) {
        if (typeof value !== 'string')
            return null;
        const [year, month, day] = value.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return Number.isFinite(date.getTime())
            ? date.toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric'})
            : null;
    }

    _facts(state) {
        if (!(state.resetCreditsAvailable > 0))
            return null;
        const row = new St.BoxLayout({style_class: 'shadow-metadata-row', x_expand: true});
        row.add_child(new St.Label({
            text: 'Reset credits',
            style_class: 'shadow-metadata-label',
            x_expand: true,
        }));
        row.add_child(new St.Label({
            text: String(state.resetCreditsAvailable),
            style_class: 'shadow-metadata-value',
        }));
        return row;
    }

    _openCodex() {
        launchUri('codex://', this.context.logger).catch(() =>
            this.context.notify?.('Shadowokx Panel', 'Codex could not be opened.'));
    }

    async _share(state) {
        if (this._sharing || (!state.weekly && !state.fiveHour))
            return;
        this._sharing = true;
        this._render();
        try {
            const configuredTheme = this.context.settings.get_string('theme');
            const interfaceTheme = configuredTheme === 'auto'
                ? St.Settings.get().color_scheme === St.SystemColorScheme.PREFER_LIGHT
                    ? 'light'
                    : 'dark'
                : configuredTheme;
            const result = await exportCodexSummaryImage(state, {
                accent: resolveAccent(this.context.settings),
                backgroundTheme: this.context.settings.get_string('background-theme'),
                interfaceTheme,
            });
            const uri = Gio.File.new_for_path(result.directoryPath).get_uri();
            this.context.notify?.('Usage image saved', result.fileName, {
                actionLabel: 'Open folder',
                action: () => launchUri(uri, this.context.logger).catch(() => {}),
            });
        } catch (error) {
            this.context.logger?.debug('codex.share.failed', {code: error.code ?? 'image-export'});
            this.context.notify?.(
                'Share failed',
                'The usage image could not be saved.'
            );
        } finally {
            this._sharing = false;
            if (!this._destroyed)
                this._render();
        }
    }

    destroy() {
        this._destroyed = true;
        this.context.scheduler.cancel('codex-countdown');
        super.destroy();
    }
}
