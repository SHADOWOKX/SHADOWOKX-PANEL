import Clutter from 'gi://Clutter';
import St from 'gi://St';

import {MODULE_META} from '../lib/constants.js';
import {accentRgba, moduleIcon, resolveAccent} from './components.js';

export class TabStrip {
    constructor(extension, settings, moduleIds, onSelected) {
        this._settings = settings;
        this._onSelected = onSelected;
        this._buttons = new Map();
        this._activeId = null;
        this.actor = new St.BoxLayout({
            style_class: 'shadow-tab-strip',
            x_expand: true,
            x_align: Clutter.ActorAlign.CENTER,
        });

        for (const id of moduleIds) {
            const meta = MODULE_META[id];
            const content = new St.BoxLayout({
                style_class: 'shadow-tab-content',
                y_align: Clutter.ActorAlign.CENTER,
            });
            const icon = moduleIcon(extension, id, 17, 'shadow-tab-icon');
            const label = new St.Label({
                text: meta.name,
                style_class: 'shadow-tab-label',
                y_align: Clutter.ActorAlign.CENTER,
            });
            label.hide();
            content.add_child(icon);
            content.add_child(label);
            const button = new St.Button({
                child: content,
                style_class: 'shadow-tab',
                can_focus: true,
                reactive: true,
                track_hover: true,
                toggle_mode: true,
                accessible_name: meta.name,
            });
            button.connect('clicked', () => {
                this._onSelected(id);
                button.checked = this._activeId === id;
            });
            button.connect('key-press-event', (_button, event) =>
                this._onKeyPress(id, event));
            this.actor.add_child(button);
            this._buttons.set(id, {button, icon, label});
        }
    }

    setActive(id) {
        if (!this._buttons.has(id))
            return;
        const hadActive = this._activeId !== null;
        this._activeId = id;
        const animate = hadActive && this._settings.get_boolean('animations');
        const accent = resolveAccent(this._settings);
        const tint = accentRgba(this._settings, 0.14);

        for (const [buttonId, {button, icon, label}] of this._buttons) {
            const active = buttonId === id;
            button.checked = active;
            button.accessible_name = active
                ? `${MODULE_META[buttonId].name}, selected`
                : MODULE_META[buttonId].name;
            button.remove_style_class_name('shadow-tab-active');
            button.style = null;
            label.remove_all_transitions();
            if (active) {
                button.add_style_class_name('shadow-tab-active');
                button.style = `background-color: ${tint};`;
                icon.style = `color: ${accent};`;
                label.show();
                if (animate) {
                    const [, naturalWidth] = label.get_preferred_width(-1);
                    label.opacity = 0;
                    label.width = 0;
                    label.ease({
                        opacity: 255,
                        width: naturalWidth,
                        duration: 140,
                        mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                        onComplete: () => { label.width = -1; },
                    });
                } else {
                    label.opacity = 255;
                    label.width = -1;
                }
            } else if (label.visible && animate) {
                icon.style = null;
                label.ease({
                    opacity: 0,
                    width: 0,
                    duration: 110,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                    onComplete: () => {
                        label.hide();
                        label.width = -1;
                    },
                });
            } else {
                icon.style = null;
                label.hide();
                label.opacity = 255;
                label.width = -1;
            }
        }
    }

    _onKeyPress(id, event) {
        const ids = [...this._buttons.keys()];
        const index = ids.indexOf(id);
        const key = event.get_key_symbol();
        let target = null;
        if (key === Clutter.KEY_Left || key === Clutter.KEY_Up)
            target = ids[(index - 1 + ids.length) % ids.length];
        else if (key === Clutter.KEY_Right || key === Clutter.KEY_Down)
            target = ids[(index + 1) % ids.length];
        else if (key === Clutter.KEY_Home)
            target = ids[0];
        else if (key === Clutter.KEY_End)
            target = ids.at(-1);
        if (!target)
            return Clutter.EVENT_PROPAGATE;
        this._onSelected(target);
        this._buttons.get(target)?.button.grab_key_focus();
        return Clutter.EVENT_STOP;
    }

    destroy() {
        this.actor.destroy();
        this._buttons.clear();
    }
}
